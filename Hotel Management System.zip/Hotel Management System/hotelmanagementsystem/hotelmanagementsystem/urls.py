from django.contrib import admin
from django.urls import path
from bookings import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.signup, name='signup'),
    path('admin/', admin.site.urls),
    path('home/', views.home, name='home'),  # Define a URL pattern for the root URL
    path('available-rooms/', views.available_rooms, name='available_rooms'),
    path('book-room/<int:room_id>/', views.book_room, name='book_room'),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

#python manage.py makemigrations
#python manage.py runserver
