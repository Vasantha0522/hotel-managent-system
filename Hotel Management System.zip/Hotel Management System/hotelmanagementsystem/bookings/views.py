from django.shortcuts import render, redirect
from .models import Room
from .forms import BookingForm
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import UserCreationForm


def home(request):
    return render(request, 'home.html')
def available_rooms(request):
    rooms = Room.objects.filter(availability=True)
    return render(request, 'available_rooms.html', {'rooms': rooms})

def book_room(request, room_id):
    room = Room.objects.get(id=room_id)
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.room = room
            booking.save()
            room.availability = False
            room.save()
            return redirect('available_rooms')
    else:
        form = BookingForm()
    return render(request, 'book_room.html', {'form': form, 'room': room})

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            # Redirect to the home page
            return redirect('home')  # Assuming 'home' is the name of the URL pattern for the home page
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')  # Redirect to home page
        else:
            # Handle invalid login credentials
            pass
    return render(request, 'login.html')